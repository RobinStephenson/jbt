results.PNG is a screenshot of a test results screen.
results.xml is a more detailed set of test results including the time they took to execute.
The "Tests" folder contains all our executable tests. 
To run these they need to be placed under Assets/Editor in our project. 
If you have downloaded our project source they will already be there.