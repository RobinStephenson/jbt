RUNNING THE GAME FROM THE JAR
Simply double click RoboticonColonyJBT.jar

RUNNING THE GAME FROM GRADLE
navigate to the project root in your terminal and run:
gradle run

BUILDING THE GAME FROM GRADLE
navigate to the project root in your terminal and run:
gradle dist

RUNNING TESTS
navigate to the project root in your terminal and run:
gradle test
